<div class="post-nav clearfix"> 
	<?php previous_post_link('<span class="prev">%link</span>', '%title'); ?> 
	<?php next_post_link('<span class="next">%link</span>', '%title'); ?> 
</div>
