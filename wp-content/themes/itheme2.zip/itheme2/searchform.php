<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
	<input type="text" name="s" id="s"  placeholder="<?php _e('Search', 'themify'); ?>">
</form>
